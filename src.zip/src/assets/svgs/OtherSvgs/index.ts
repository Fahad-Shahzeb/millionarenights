import EllipseShaded from './EllipseShaded.svg';
import IPhoneBG from './IPhoneBG.svg';
import ShadedFlag from './ShadedFlag.svg';
import BurgerMenu from './BurgerMenu.svg';
import Iphone from './Iphone.svg';
export { EllipseShaded, IPhoneBG, ShadedFlag, BurgerMenu, Iphone };
