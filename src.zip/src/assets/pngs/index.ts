import AppLogo_PNG from "./applogo.png";
import DollarCoin_PNG from "./dollar-coin.png";
import Globe_PNG from "./globe.png";
import HeartCoin_PNG from "./heart-coin.png";
import Iphone_PNG from "./iphone.png";
import UserAvatar_PNG from "./user.png";
import LogoCoin_PNG from "./logo-coin.png";
import cryptonews from "./cryptonews.png";
import coincierge from "./coincierge.png";
import coinspeaker from "./Coinspeaker.png";
import cointelegraph from "./ciontelegrph.png";
import Ellipse30 from "./Ellipse30.png";
import Ellipse28 from "./Ellipse28.png";
import Logo from "./logo.png";
import ShadyDotsIcon2 from "./ShadyDotsIcon.png";
import CardsSection1 from "./cardsSectionImage_1.png";
import CardsSection2 from "./cardsSectionImage_2.png";
import CarImageIphone from "./CarImageIphone.png";
import ValuePNG from "./ValuePNG.png";
import InvestmentPNG from "./InvestmentPNG.png";
import TransparencyPNG from "./TransparencyPNG.png";
import IncomePNG from "./IncomePNG.png";
import HorizontalLinesPNG from "./HorizontalLinesPNG.png";
import FlowChartPNG from "./FlowChartPNG.png";
import User2 from "./1.png";
import AffliateProgramEllipsePNG from "./AffliateProgramEllipsePNG.png";
import FlagPNG from "./FlagPNG.png";
import RoadMapDotsPNG from "./RoadMapDotsPNG.png";
import BackIcon from "./BackIcon.png";
import Ellipse from "./Ecllipse.png";

//Gradients
import Gradient_1 from "./Gradient_1.png";
import Mobile_Gradient_1 from "./Mobile_Gradient_1.png";
import Gradient_2 from "./Gradient_2.png";
import Gradient_2_1 from "./Gradient_2_1.png";
import Gradient_2__1 from "./Gradient_2__1.png";
import Mobile_Gradient_2 from "./Mobile_Gradient_2.png";
import Gradient_3 from "./Gradient_3.png";
import Gradient_3_1 from "./Gradient_3_1.png";
import Mobile_Gradient_3 from "./Mobile_Gradient_3.png";
import Gradient_4 from "./Gradient_4.png";
import Gradient_4_1 from "./Gradient_4_1.png";
import Mobile_Gradient_4 from "./Mobile_Gradient_4.png";
import Gradient_5 from "./Gradient_5.png";
import Mobile_Gradient_5 from "./Mobile_Gradient_5.png";
import Gradient_6 from "./Gradient_6.png";
import Mobile_Gradient_6 from "./Mobile_Gradient_6.png";
import RoadMapLeftPNG from "./RoadMapLeftPNG.png";
import RoadMapRightPNG from "./RoadMapRightPNG.png";
import CircleGradient from "./CircleGradient.png";

// Exports
export {
  AppLogo_PNG,
  Gradient_1,
  Mobile_Gradient_1,
  Gradient_2,
  Gradient_2_1,
  Gradient_2__1,
  Mobile_Gradient_2,
  Gradient_3,
  Gradient_3_1,
  Mobile_Gradient_3,
  Gradient_4,
  Gradient_4_1,
  Mobile_Gradient_4,
  Gradient_5,
  Mobile_Gradient_5,
  Gradient_6,
  Mobile_Gradient_6,
  RoadMapLeftPNG,
  RoadMapRightPNG,
  DollarCoin_PNG,
  HeartCoin_PNG,
  UserAvatar_PNG,
  Iphone_PNG,
  Globe_PNG,
  LogoCoin_PNG,
  cryptonews,
  coincierge,
  coinspeaker,
  cointelegraph,
  Ellipse30,
  Ellipse28,
  Logo,
  ShadyDotsIcon2,
  CardsSection1,
  CardsSection2,
  CarImageIphone,
  ValuePNG,
  IncomePNG,
  InvestmentPNG,
  TransparencyPNG,
  HorizontalLinesPNG,
  FlowChartPNG,
  User2,
  AffliateProgramEllipsePNG,
  FlagPNG,
  RoadMapDotsPNG,
  BackIcon,
  CircleGradient,
  Ellipse,
};
